# 📁 Documentation Folder

This folder contains sample PDF documents for testing the RAG functionality.

## 📄 Sample Documents

### Services Information
Upload PDF documents containing:
- Service descriptions
- Pricing information  
- Operating hours
- Policies and guidelines
- Contact information

### How to Use
1. Click "Upload PDF Documents" in the chat interface
2. Select PDF files from this folder or your own documents
3. Click "Process PDFs" to add them to the knowledge base
4. Ask questions about the uploaded content

### Sample Questions to Test
- "What services do you offer?"
- "What are your operating hours?"
- "How much does a doctor consultation cost?"
- "What is your cancellation policy?"
- "Tell me about your payment methods"

## 📝 Notes
- PDFs should contain text (not just images)
- Multiple PDFs can be uploaded and processed
- The system will extract text and create embeddings for semantic search
- Processed documents are stored in ChromaDB vector store

## 🔧 Customization
Replace these sample documents with your own service information, policies, or any knowledge base content relevant to your booking domain.
