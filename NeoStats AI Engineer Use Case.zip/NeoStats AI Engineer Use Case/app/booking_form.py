import streamlit as st
from datetime import datetime, timedelta
import re

def render_booking_form():
    """Render hotel booking form"""
    st.title("🏨 Complete Your Booking")
    
    if 'selected_hotel' not in st.session_state:
        st.warning("⚠️ Please select a hotel first!")
        return
    
    hotel = st.session_state.selected_hotel
    
    # Hotel summary
    with st.container():
        col1, col2 = st.columns([2, 1])
        with col1:
            st.subheader(f"🏨 {hotel['name']}")
            st.markdown(f"⭐ Rating: {hotel['rating']}/5")
            st.markdown(f"💰 Price: ₹{hotel['price']}/night")
            st.markdown(f"📍 Location: {hotel.get('location', 'Goa')}")
        
        with col2:
            st.image(hotel.get('image', 'https://via.placeholder.com/300x200.png?text=Hotel'), width=200)
    
    # Booking form
    st.markdown("---")
    st.subheader("📝 Guest Information")
    
    # Initialize booking data in session state
    if 'booking_data' not in st.session_state:
        st.session_state.booking_data = {
            'hotel_name': hotel['name'],
            'name': '',
            'email': '',
            'phone': '',
            'check_in': datetime.now().date(),
            'check_out': (datetime.now() + timedelta(days=1)).date(),
            'adults': 1,
            'children': 0,
            'rooms': 1,
            'special_requests': ''
        }
    
    # Guest details
    col1, col2 = st.columns(2)
    with col1:
        st.session_state.booking_data['name'] = st.text_input(
            "Full Name *", 
            value=st.session_state.booking_data['name'],
            key="guest_name"
        )
        
        st.session_state.booking_data['email'] = st.text_input(
            "Email Address *", 
            value=st.session_state.booking_data['email'],
            key="guest_email"
        )
        
        st.session_state.booking_data['phone'] = st.text_input(
            "Phone Number *", 
            value=st.session_state.booking_data['phone'],
            key="guest_phone"
        )
    
    with col2:
        st.session_state.booking_data['check_in'] = st.date_input(
            "Check-in Date *",
            value=st.session_state.booking_data['check_in'],
            key="check_in_date"
        )
        
        st.session_state.booking_data['check_out'] = st.date_input(
            "Check-out Date *",
            value=st.session_state.booking_data['check_out'],
            key="check_out_date"
        )
    
    # Room details
    col1, col2, col3 = st.columns(3)
    with col1:
        st.session_state.booking_data['adults'] = st.number_input(
            "Adults *",
            min_value=1,
            max_value=10,
            value=st.session_state.booking_data['adults'],
            key="adults_count"
        )
    
    with col2:
        st.session_state.booking_data['children'] = st.number_input(
            "Children",
            min_value=0,
            max_value=10,
            value=st.session_state.booking_data['children'],
            key="children_count"
        )
    
    with col3:
        st.session_state.booking_data['rooms'] = st.number_input(
            "Rooms *",
            min_value=1,
            max_value=5,
            value=st.session_state.booking_data['rooms'],
            key="rooms_count"
        )
    
    # Special requests
    st.session_state.booking_data['special_requests'] = st.text_area(
        "Special Requests",
        value=st.session_state.booking_data['special_requests'],
        key="special_requests",
        placeholder="Any special requirements or preferences..."
    )
    
    # Price calculation
    nights = (st.session_state.booking_data['check_out'] - st.session_state.booking_data['check_in']).days
    total_price = hotel['price'] * nights * st.session_state.booking_data['rooms']
    
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("📅 Nights", nights)
    with col2:
        st.metric("💰 Total Price", f"₹{total_price}")
    with col3:
        st.metric("🏨 Rooms", st.session_state.booking_data['rooms'])
    
    # Booking confirmation
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🔙 Back to Hotels", key="back_hotels", use_container_width=True):
            st.session_state.current_page = "hotel_booking"
            st.rerun()
    
    with col2:
        if st.button("✅ Confirm Booking", key="confirm_booking", type="primary", use_container_width=True):
            if validate_booking_form():
                process_booking_confirmation()
            else:
                st.error("⚠️ Please fill in all required fields marked with *")

def validate_booking_form():
    """Validate booking form"""
    data = st.session_state.booking_data
    
    # Check required fields
    required_fields = ['name', 'email', 'phone']
    for field in required_fields:
        if not data[field] or data[field].strip() == '':
            st.error(f"⚠️ {field.replace('_', ' ').title()} is required")
            return False
    
    # Email validation
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(email_pattern, data['email']):
        st.error("⚠️ Please enter a valid email address")
        return False
    
    # Phone validation
    phone = re.sub(r'[^\d]', '', data['phone'])
    if len(phone) < 10:
        st.error("⚠️ Please enter a valid phone number (at least 10 digits)")
        return False
    
    # Date validation
    if data['check_in'] >= data['check_out']:
        st.error("⚠️ Check-out date must be after check-in date")
        return False
    
    return True

def process_booking_confirmation():
    """Process booking confirmation"""
    try:
        # Create booking data
        booking_data = {
            'name': st.session_state.booking_data['name'],
            'email': st.session_state.booking_data['email'],
            'phone': st.session_state.booking_data['phone'],
            'booking_type': f"Hotel Booking - {st.session_state.selected_hotel['name']}",
            'date': st.session_state.booking_data['check_in'].strftime('%Y-%m-%d'),
            'time': '14:00',  # Default check-in time
            'additional_info': {
                'hotel_name': st.session_state.selected_hotel['name'],
                'check_out': st.session_state.booking_data['check_out'].strftime('%Y-%m-%d'),
                'adults': st.session_state.booking_data['adults'],
                'children': st.session_state.booking_data['children'],
                'rooms': st.session_state.booking_data['rooms'],
                'special_requests': st.session_state.booking_data['special_requests'],
                'total_price': calculate_total_price()
            }
        }
        
        # Save booking to database
        from app.tools import ToolRouter
        tool_router = ToolRouter()
        
        result = tool_router.call_tool("booking", "create_booking", booking_data=booking_data)
        
        if result.get("success"):
            # Send confirmation email
            booking_id = result.get("booking_id", "")
            email_result = tool_router.call_tool(
                "email", 
                "send_booking_confirmation",
                booking_data=booking_data,
                booking_id=booking_id
            )
            
            # Show success message
            st.success("🎉 Booking Confirmed!")
            st.markdown(f"### ✅ Your booking has been confirmed!")
            st.markdown(f"**Booking ID:** {booking_id}")
            st.markdown(f"**Hotel:** {st.session_state.selected_hotel['name']}")
            st.markdown(f"**Check-in:** {booking_data['date']}")
            st.markdown(f"**Total Amount:** ₹{calculate_total_price()}")
            
            if email_result.get("success"):
                st.success("📧 Confirmation email sent!")
            else:
                st.warning(f"⚠️ Email not sent: {email_result.get('message', 'Unknown error')}")
            
            # Reset booking data
            del st.session_state.booking_data
            del st.session_state.selected_hotel
            st.session_state.current_page = "booking_success"
            st.rerun()
        
        else:
            st.error(f"❌ Booking failed: {result.get('message', 'Unknown error')}")
    
    except Exception as e:
        st.error(f"❌ Error processing booking: {str(e)}")

def calculate_total_price():
    """Calculate total booking price"""
    if 'selected_hotel' not in st.session_state:
        return 0
    
    hotel = st.session_state.selected_hotel
    nights = (st.session_state.booking_data['check_out'] - st.session_state.booking_data['check_in']).days
    return hotel['price'] * nights * st.session_state.booking_data['rooms']
