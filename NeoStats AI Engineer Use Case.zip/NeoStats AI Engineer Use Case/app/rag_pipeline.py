import os
import tempfile
from typing import List, Dict, Any, Optional
import streamlit as st
import PyPDF2
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_classic.chains import RetrievalQA
from langchain_openai import OpenAI

from app.config import Config

class RAGPipeline:
    """RAG (Retrieval-Augmented Generation) pipeline for PDF processing and Q&A"""
    
    def __init__(self):
        self.embeddings = None
        self.vector_store = None
        self.qa_chain = None
        self.processed_files = []
        
        # Initialize embeddings
        if Config.OPENAI_API_KEY:
            self.embeddings = OpenAIEmbeddings(openai_api_key=Config.OPENAI_API_KEY)
            # Initialize or load vector store
            self._init_vector_store()
    
    def _init_vector_store(self):
        """Initialize or load existing vector store"""
        try:
            if os.path.exists(Config.CHROMA_PERSIST_DIR):
                self.vector_store = Chroma(
                    persist_directory=Config.CHROMA_PERSIST_DIR,
                    embedding_function=self.embeddings
                )
            else:
                # Create new vector store
                os.makedirs(Config.CHROMA_PERSIST_DIR, exist_ok=True)
                self.vector_store = Chroma(
                    persist_directory=Config.CHROMA_PERSIST_DIR,
                    embedding_function=self.embeddings
                )
            
            # Initialize QA chain
            if self.vector_store:
                llm = OpenAI(openai_api_key=Config.OPENAI_API_KEY)
                self.qa_chain = RetrievalQA.from_chain_type(
                    llm=llm,
                    chain_type="stuff",
                    retriever=self.vector_store.as_retriever(),
                    return_source_documents=True
                )
        except Exception as e:
            st.error(f"Error initializing RAG pipeline: {str(e)}")
    
    def extract_text_from_pdf(self, pdf_file) -> str:
        """Extract text from PDF file"""
        try:
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                tmp_file.write(pdf_file.getvalue())
                tmp_file_path = tmp_file.name
            
            # Extract text
            text = ""
            with open(tmp_file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
            
            # Clean up temporary file
            os.unlink(tmp_file_path)
            
            return text
        except Exception as e:
            raise Exception(f"Error extracting text from PDF: {str(e)}")
    
    def chunk_text(self, text: str) -> List[Document]:
        """Split text into chunks"""
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=Config.CHUNK_SIZE,
            chunk_overlap=Config.CHUNK_OVERLAP,
            length_function=len
        )
        
        chunks = text_splitter.split_text(text)
        documents = [Document(page_content=chunk) for chunk in chunks]
        
        return documents
    
    def process_pdf(self, pdf_file) -> bool:
        """Process a single PDF file"""
        try:
            # Extract text
            text = self.extract_text_from_pdf(pdf_file)
            
            if not text.strip():
                raise Exception("No text extracted from PDF")
            
            # Chunk text
            documents = self.chunk_text(text)
            
            # Add to vector store
            if self.vector_store and self.embeddings:
                self.vector_store.add_documents(documents)
                self.vector_store.persist()
                
                # Track processed file
                self.processed_files.append(pdf_file.name)
                return True
            else:
                raise Exception("Vector store or embeddings not initialized")
                
        except Exception as e:
            raise Exception(f"Error processing PDF {pdf_file.name}: {str(e)}")
    
    def query(self, question: str) -> Dict[str, Any]:
        """Query the RAG pipeline"""
        try:
            if not self.qa_chain:
                raise Exception("QA chain not initialized")
            
            result = self.qa_chain({"query": question})
            
            return {
                "answer": result.get("result", ""),
                "source_documents": result.get("source_documents", []),
                "success": True
            }
            
        except Exception as e:
            return {
                "answer": f"Error processing query: {str(e)}",
                "source_documents": [],
                "success": False
            }
    
    def is_ready(self) -> bool:
        """Check if RAG pipeline is ready for queries"""
        return self.embeddings is not None and self.vector_store is not None and self.qa_chain is not None
    
    def get_processed_files(self) -> List[str]:
        """Get list of processed files"""
        return self.processed_files.copy()
    
    def clear_vector_store(self):
        """Clear the vector store"""
        try:
            if os.path.exists(Config.CHROMA_PERSIST_DIR):
                import shutil
                shutil.rmtree(Config.CHROMA_PERSIST_DIR)
            
            self._init_vector_store()
            self.processed_files = []
            
        except Exception as e:
            raise Exception(f"Error clearing vector store: {str(e)}")
    
    def get_document_count(self) -> int:
        """Get number of documents in vector store"""
        try:
            if self.vector_store:
                return self.vector_store._collection.count()
            return 0
        except:
            return 0
