import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go

from db.database import DatabaseService
from app.tools import ToolRouter

class AdminDashboard:
    """Admin dashboard for viewing and managing bookings"""
    
    def __init__(self):
        self.db_service = DatabaseService()
        self.tool_router = ToolRouter()
    
    def render(self):
        """Render the admin dashboard"""
        st.title("📊 Admin Dashboard")
        st.markdown("View and manage all bookings in the system.")
        
        # Refresh button
        if st.button("🔄 Refresh Data", key="refresh_admin"):
            st.rerun()
        
        # Get booking statistics
        stats_result = self.tool_router.call_tool("booking", "get_stats")
        
        if stats_result.get("success"):
            stats = stats_result.get("stats", {})
            self._render_stats_cards(stats)
        
        # Tabs for different views
        tab1, tab2, tab3 = st.tabs(["📋 All Bookings", "🔍 Search", "📈 Analytics"])
        
        with tab1:
            self._render_all_bookings()
        
        with tab2:
            self._render_search_bookings()
        
        with tab3:
            self._render_analytics(stats_result.get("stats", {}))
    
    def _render_stats_cards(self, stats: dict):
        """Render statistics cards"""
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="📅 Total Bookings",
                value=stats.get("total_bookings", 0)
            )
        
        with col2:
            st.metric(
                label="🆕 Recent (7 days)",
                value=stats.get("recent_bookings", 0)
            )
        
        with col3:
            booking_types = stats.get("bookings_by_type", {})
            st.metric(
                label="🏷️ Booking Types",
                value=len(booking_types)
            )
        
        with col4:
            # Calculate today's bookings
            today_bookings = self._get_today_bookings_count()
            st.metric(
                label="📆 Today's Bookings",
                value=today_bookings
            )
        
        st.markdown("---")
    
    def _render_all_bookings(self):
        """Render all bookings table"""
        st.subheader("📋 All Bookings")
        
        # Get all bookings
        bookings_result = self.tool_router.call_tool("booking", "get_bookings")
        
        if bookings_result.get("success"):
            bookings = bookings_result.get("bookings", [])
            
            if bookings:
                # Convert to DataFrame
                df = pd.DataFrame(bookings)
                
                # Format dates
                if 'created_at' in df.columns:
                    df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M')
                
                if 'date' in df.columns:
                    df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
                
                # Display table
                st.dataframe(
                    df,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "id": st.column_config.TextColumn("Booking ID"),
                        "customer_name": st.column_config.TextColumn("Name"),
                        "customer_email": st.column_config.TextColumn("Email"),
                        "customer_phone": st.column_config.TextColumn("Phone"),
                        "booking_type": st.column_config.TextColumn("Type"),
                        "date": st.column_config.TextColumn("Date"),
                        "time": st.column_config.TextColumn("Time"),
                        "status": st.column_config.TextColumn("Status"),
                        "created_at": st.column_config.TextColumn("Created")
                    }
                )
                
                # Export functionality
                if st.button("📥 Export to CSV", key="export_all"):
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="Download CSV",
                        data=csv,
                        file_name=f"bookings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
            else:
                st.info("No bookings found.")
        else:
            st.error(f"Error loading bookings: {bookings_result.get('message', 'Unknown error')}")
    
    def _render_search_bookings(self):
        """Render search functionality"""
        st.subheader("🔍 Search Bookings")
        
        # Search input
        search_query = st.text_input(
            "Search by name, email, or booking type:",
            placeholder="Enter search term...",
            key="admin_search"
        )
        
        if search_query:
            bookings_result = self.tool_router.call_tool("booking", "get_bookings", search_query=search_query)
            
            if bookings_result.get("success"):
                bookings = bookings_result.get("bookings", [])
                
                if bookings:
                    st.success(f"Found {len(bookings)} booking(s) matching '{search_query}'")
                    
                    # Convert to DataFrame
                    df = pd.DataFrame(bookings)
                    
                    # Format dates
                    if 'created_at' in df.columns:
                        df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M')
                    
                    if 'date' in df.columns:
                        df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
                    
                    # Display results
                    st.dataframe(
                        df,
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            "id": st.column_config.TextColumn("Booking ID"),
                            "customer_name": st.column_config.TextColumn("Name"),
                            "customer_email": st.column_config.TextColumn("Email"),
                            "customer_phone": st.column_config.TextColumn("Phone"),
                            "booking_type": st.column_config.TextColumn("Type"),
                            "date": st.column_config.TextColumn("Date"),
                            "time": st.column_config.TextColumn("Time"),
                            "status": st.column_config.TextColumn("Status"),
                            "created_at": st.column_config.TextColumn("Created")
                        }
                    )
                else:
                    st.info(f"No bookings found matching '{search_query}'.")
            else:
                st.error(f"Error searching bookings: {bookings_result.get('message', 'Unknown error')}")
        
        # Advanced filters
        with st.expander("🔧 Advanced Filters"):
            col1, col2 = st.columns(2)
            
            with col1:
                # Date range filter
                start_date = st.date_input("Start Date", datetime.now() - timedelta(days=30))
                end_date = st.date_input("End Date", datetime.now())
            
            with col2:
                # Booking type filter
                booking_types = ["All"] + ["Doctor Consultation", "Salon Appointment", "Hotel Reservation", 
                                           "Event Registration", "Class Booking", "Restaurant Reservation"]
                selected_type = st.selectbox("Booking Type", booking_types)
            
            # Apply filters button
            if st.button("🔍 Apply Filters"):
                self._apply_filters(start_date, end_date, selected_type)
    
    def _render_analytics(self, stats: dict):
        """Render analytics charts"""
        st.subheader("📈 Booking Analytics")
        
        # Bookings by type chart
        bookings_by_type = stats.get("bookings_by_type", {})
        
        if bookings_by_type:
            col1, col2 = st.columns(2)
            
            with col1:
                # Pie chart for booking types
                fig_pie = px.pie(
                    values=list(bookings_by_type.values()),
                    names=list(bookings_by_type.keys()),
                    title="Bookings by Type"
                )
                st.plotly_chart(fig_pie, use_container_width=True)
            
            with col2:
                # Bar chart for booking types
                fig_bar = px.bar(
                    x=list(bookings_by_type.keys()),
                    y=list(bookings_by_type.values()),
                    title="Bookings by Type (Bar Chart)"
                )
                fig_bar.update_xaxes(title="Booking Type")
                fig_bar.update_yaxes(title="Number of Bookings")
                st.plotly_chart(fig_bar, use_container_width=True)
        else:
            st.info("No booking data available for analytics.")
        
        # Time-based analytics
        st.subheader("📅 Booking Trends")
        
        # Get recent bookings for trend analysis
        bookings_result = self.tool_router.call_tool("booking", "get_bookings")
        
        if bookings_result.get("success"):
            bookings = bookings_result.get("bookings", [])
            
            if bookings:
                # Create DataFrame for time analysis
                df = pd.DataFrame(bookings)
                
                if 'created_at' in df.columns:
                    df['created_at'] = pd.to_datetime(df['created_at'])
                    df['date'] = df['created_at'].dt.date
                    df['hour'] = df['created_at'].dt.hour
                    
                    # Bookings by date
                    daily_bookings = df.groupby('date').size().reset_index(name='count')
                    
                    fig_time = px.line(
                        daily_bookings,
                        x='date',
                        y='count',
                        title="Bookings Over Time",
                        markers=True
                    )
                    fig_time.update_xaxes(title="Date")
                    fig_time.update_yaxes(title="Number of Bookings")
                    st.plotly_chart(fig_time, use_container_width=True)
                    
                    # Bookings by hour of day
                    hourly_bookings = df.groupby('hour').size().reset_index(name='count')
                    
                    fig_hour = px.bar(
                        hourly_bookings,
                        x='hour',
                        y='count',
                        title="Bookings by Hour of Day"
                    )
                    fig_hour.update_xaxes(title="Hour of Day")
                    fig_hour.update_yaxes(title="Number of Bookings")
                    st.plotly_chart(fig_hour, use_container_width=True)
        
        # System status
        st.subheader("🔧 System Status")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # RAG status
            rag_status = self.tool_router.call_tool("rag", "get_status")
            if rag_status.get("success"):
                st.metric(
                    "📚 Knowledge Base",
                    f"{rag_status.get('document_count', 0)} docs"
                )
        
        with col2:
            # Database status
            st.metric(
                "💾 Database",
                "✅ Connected"
            )
        
        with col3:
            # Email status
            email_config = self.tool_router.email_tool.email_config
            st.metric(
                "📧 Email Service",
                email_config.get("provider", "Not configured").title()
            )
    
    def _get_today_bookings_count(self) -> int:
        """Get count of bookings for today"""
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            bookings_result = self.tool_router.call_tool("booking", "get_bookings")
            
            if bookings_result.get("success"):
                bookings = bookings_result.get("bookings", [])
                today_bookings = [b for b in bookings if b.get('date') == today]
                return len(today_bookings)
        except:
            pass
        
        return 0
    
    def _apply_filters(self, start_date, end_date, selected_type):
        """Apply advanced filters to bookings"""
        try:
            bookings_result = self.tool_router.call_tool("booking", "get_bookings")
            
            if bookings_result.get("success"):
                bookings = bookings_result.get("bookings", [])
                
                # Apply date filter
                filtered_bookings = []
                for booking in bookings:
                    booking_date = pd.to_datetime(booking.get('date')).date()
                    
                    # Check date range
                    if start_date <= booking_date <= end_date:
                        # Check booking type
                        if selected_type == "All" or booking.get('booking_type') == selected_type:
                            filtered_bookings.append(booking)
                
                if filtered_bookings:
                    st.success(f"Found {len(filtered_bookings)} booking(s) with applied filters")
                    
                    # Display filtered results
                    df = pd.DataFrame(filtered_bookings)
                    
                    # Format dates
                    if 'created_at' in df.columns:
                        df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M')
                    
                    if 'date' in df.columns:
                        df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
                    
                    st.dataframe(
                        df,
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            "id": st.column_config.TextColumn("Booking ID"),
                            "customer_name": st.column_config.TextColumn("Name"),
                            "customer_email": st.column_config.TextColumn("Email"),
                            "customer_phone": st.column_config.TextColumn("Phone"),
                            "booking_type": st.column_config.TextColumn("Type"),
                            "date": st.column_config.TextColumn("Date"),
                            "time": st.column_config.TextColumn("Time"),
                            "status": st.column_config.TextColumn("Status"),
                            "created_at": st.column_config.TextColumn("Created")
                        }
                    )
                else:
                    st.info("No bookings found with the applied filters.")
            else:
                st.error(f"Error filtering bookings: {bookings_result.get('message', 'Unknown error')}")
                
        except Exception as e:
            st.error(f"Error applying filters: {str(e)}")
