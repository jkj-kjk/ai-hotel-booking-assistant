"""
AI Booking Assistant Application Package

This package contains all the core components of the AI Booking Assistant:
- Main Streamlit application
- Chat logic and intent detection
- Booking flow management
- RAG pipeline for PDF processing
- Tools for various operations
- Admin dashboard
- Configuration settings
"""

__version__ = "1.0.0"
__author__ = "AI Engineer"
__description__ = "AI-driven Booking Assistant with RAG capabilities"
