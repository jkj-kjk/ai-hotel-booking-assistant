import re
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import json

from app.config import Config
from db.database import DatabaseService

class BookingFlow:
    """Manages the booking conversation flow and slot filling"""
    
    def __init__(self):
        self.db_service = DatabaseService()
        self.booking_slots = {
            'name': None,
            'email': None,
            'phone': None,
            'booking_type': None,
            'date': None,
            'time': None
        }
        self.confirmation_requested = False
        self.booking_completed = False
        
    def reset_booking_flow(self):
        """Reset the booking flow for a new booking"""
        self.booking_slots = {
            'name': None,
            'email': None,
            'phone': None,
            'booking_type': None,
            'date': None,
            'time': None
        }
        self.confirmation_requested = False
        self.booking_completed = False
    
    def extract_booking_info(self, message: str) -> Dict[str, Any]:
        """Extract booking information from user message"""
        extracted_info = {}
        
        # Extract name
        name_patterns = [
            r'my name is (\w+(?:\s+\w+)*)',
            r'i am (\w+(?:\s+\w+)*)',
            r'i\'m (\w+(?:\s+\w+)*)',
            r'call me (\w+(?:\s+\w+)*)'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                extracted_info['name'] = match.group(1).title()
                break
        
        # Extract email
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        email_match = re.search(email_pattern, message)
        if email_match:
            extracted_info['email'] = email_match.group(0)
        
        # Extract phone
        phone_patterns = [
            r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',  # US format
            r'\b\+?\d{10,15}\b'  # International format
        ]
        
        for pattern in phone_patterns:
            match = re.search(pattern, message)
            if match:
                extracted_info['phone'] = match.group(0)
                break
        
        # Extract booking type
        for booking_type in Config.BOOKING_TYPES:
            if booking_type.lower() in message.lower():
                extracted_info['booking_type'] = booking_type
                break
        
        # Extract date
        date_patterns = [
            r'\b\d{4}-\d{2}-\d{2}\b',  # YYYY-MM-DD
            r'\b\d{2}/\d{2}/\d{4}\b',  # MM/DD/YYYY
            r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{4}\b'  # Month DD, YYYY
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                date_str = match.group(0)
                # Convert to YYYY-MM-DD format
                try:
                    if '-' in date_str:
                        extracted_info['date'] = date_str
                    elif '/' in date_str:
                        parts = date_str.split('/')
                        extracted_info['date'] = f"{parts[2]}-{parts[0].zfill(2)}-{parts[1].zfill(2)}"
                    else:
                        # Handle Month DD, YYYY format (simplified)
                        today = datetime.now()
                        if 'tomorrow' in message.lower():
                            extracted_info['date'] = (today + timedelta(days=1)).strftime('%Y-%m-%d')
                        elif 'today' in message.lower():
                            extracted_info['date'] = today.strftime('%Y-%m-%d')
                except:
                    pass
                break
        
        # Extract time
        time_patterns = [
            r'\b\d{1,2}:\d{2}\s*(?:am|pm)?\b',  # HH:MM AM/PM
            r'\b\d{1,2}\s*(?:am|pm)\b'  # H AM/PM
        ]
        
        for pattern in time_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                time_str = match.group(0)
                # Convert to HH:MM format
                try:
                    if ':' in time_str:
                        if 'pm' in time_str.lower() and not time_str.startswith('12'):
                            hour = int(time_str.split(':')[0]) + 12
                        elif 'am' in time_str.lower() and time_str.startswith('12'):
                            hour = 0
                        else:
                            hour = int(time_str.split(':')[0])
                        minute = time_str.split(':')[1].replace('am', '').replace('pm', '').strip()
                        extracted_info['time'] = f"{hour:02d}:{minute}"
                    else:
                        # Handle H AM/PM format
                        if 'pm' in time_str.lower() and not time_str.startswith('12'):
                            hour = int(time_str.replace('pm', '').strip()) + 12
                        elif 'am' in time_str.lower() and time_str.startswith('12'):
                            hour = 0
                        else:
                            hour = int(time_str.replace('am', '').strip())
                        extracted_info['time'] = f"{hour:02d}:00"
                except:
                    pass
                break
        
        return extracted_info
    
    def update_booking_slots(self, extracted_info: Dict[str, Any]):
        """Update booking slots with extracted information"""
        for key, value in extracted_info.items():
            if key in self.booking_slots and value:
                self.booking_slots[key] = value
    
    def get_missing_slots(self) -> List[str]:
        """Get list of missing booking information"""
        missing = []
        for key, value in self.booking_slots.items():
            if not value:
                missing.append(key)
        return missing
    
    def get_next_question(self) -> str:
        """Get the next question to ask based on missing slots"""
        missing = self.get_missing_slots()
        
        if not missing:
            return None
        
        # Priority order for asking questions
        question_order = ['name', 'email', 'phone', 'booking_type', 'date', 'time']
        
        for slot in question_order:
            if slot in missing:
                return self._get_question_for_slot(slot)
        
        return None
    
    def _get_question_for_slot(self, slot: str) -> str:
        """Get the specific question for a missing slot"""
        questions = {
            'name': "What's your name?",
            'email': "What's your email address?",
            'phone': "What's your phone number?",
            'booking_type': f"What type of booking would you like to make? Available options: {', '.join(Config.BOOKING_TYPES)}",
            'date': "What date would you like to book? (Please use YYYY-MM-DD format)",
            'time': "What time would you prefer? (Please use HH:MM format)"
        }
        
        return questions.get(slot, f"Could you please provide your {slot}?")
    
    def generate_confirmation_summary(self) -> str:
        """Generate a summary of the booking details for confirmation"""
        summary = "Please confirm your booking details:\n\n"
        summary += f"**Name:** {self.booking_slots['name']}\n"
        summary += f"**Email:** {self.booking_slots['email']}\n"
        summary += f"**Phone:** {self.booking_slots['phone']}\n"
        summary += f"**Booking Type:** {self.booking_slots['booking_type']}\n"
        summary += f"**Date:** {self.booking_slots['date']}\n"
        summary += f"**Time:** {self.booking_slots['time']}\n\n"
        summary += "Please reply with 'confirm' to proceed with the booking, or let me know what needs to be changed."
        
        return summary
    
    def validate_booking_data(self) -> Tuple[bool, List[str]]:
        """Validate all booking data"""
        booking_data = {k: v for k, v in self.booking_slots.items() if v is not None}
        return self.db_service.validate_booking_data(booking_data)
    
    def process_confirmation(self, message: str) -> Dict[str, Any]:
        """Process user confirmation response"""
        message_lower = message.lower().strip()
        
        # Check for confirmation
        if message_lower in ['confirm', 'yes', 'confirmed', 'proceed', 'book it']:
            return self.complete_booking()
        
        # Check for cancellation
        elif message_lower in ['cancel', 'no', 'stop', 'never mind']:
            self.reset_booking_flow()
            return {
                "success": False,
                "message": "Booking cancelled. How can I help you with anything else?",
                "booking_id": None
            }
        
        # Check for changes
        elif any(word in message_lower for word in ['change', 'modify', 'different', 'wrong']):
            # Extract what needs to be changed
            for slot in self.booking_slots:
                if slot in message_lower:
                    return {
                        "success": False,
                        "message": f"What would you like to change your {slot.replace('_', ' ')} to?",
                        "booking_id": None,
                        "request_change": slot
                    }
        
        return {
            "success": False,
            "message": "Please reply with 'confirm' to proceed with the booking, or let me know what needs to be changed.",
            "booking_id": None
        }
    
    def complete_booking(self) -> Dict[str, Any]:
        """Complete the booking process"""
        try:
            # Validate data
            is_valid, errors = self.validate_booking_data()
            if not is_valid:
                return {
                    "success": False,
                    "message": f"Validation errors: {'; '.join(errors)}",
                    "booking_id": None
                }
            
            # Create or get customer
            customer_id = self.db_service.create_or_get_customer(
                self.booking_slots['name'],
                self.booking_slots['email'],
                self.booking_slots['phone']
            )
            
            # Create booking
            booking_id = self.db_service.create_booking(
                customer_id=customer_id,
                booking_type=self.booking_slots['booking_type'],
                date=self.booking_slots['date'],
                time=self.booking_slots['time']
            )
            
            # Mark as completed
            self.booking_completed = True
            
            return {
                "success": True,
                "message": f"Booking confirmed! Your booking ID is {booking_id}. A confirmation email has been sent to {self.booking_slots['email']}.",
                "booking_id": booking_id,
                "booking_details": self.booking_slots.copy()
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error completing booking: {str(e)}",
                "booking_id": None
            }
    
    def is_booking_complete(self) -> bool:
        """Check if booking is completed"""
        return self.booking_completed
    
    def needs_confirmation(self) -> bool:
        """Check if confirmation is needed"""
        missing_slots = self.get_missing_slots()
        return len(missing_slots) == 0 and not self.confirmation_requested
    
    def get_booking_progress(self) -> Dict[str, Any]:
        """Get current booking progress"""
        return {
            "slots": self.booking_slots.copy(),
            "missing": self.get_missing_slots(),
            "confirmation_requested": self.confirmation_requested,
            "completed": self.booking_completed
        }
