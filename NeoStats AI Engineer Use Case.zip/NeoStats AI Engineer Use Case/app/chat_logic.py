import re
from typing import List, Dict, Any, Optional
import streamlit as st

from app.booking_flow import BookingFlow
from app.tools import ToolRouter
from app.config import Config

class ChatLogic:
    """Main chat logic handler for intent detection and conversation management"""
    
    def __init__(self):
        self.booking_flow = BookingFlow()
        self.tool_router = ToolRouter()
        self.chat_history = []
        self.max_memory_length = Config.MAX_MEMORY_LENGTH
        
    def add_message(self, role: str, content: str):
        """Add a message to chat history"""
        self.chat_history.append({
            "role": role,
            "content": content,
            "timestamp": self._get_timestamp()
        })
        
        # Trim history if it exceeds max length
        if len(self.chat_history) > self.max_memory_length:
            self.chat_history = self.chat_history[-self.max_memory_length:]
    
    def get_chat_history(self) -> List[Dict[str, Any]]:
        """Get the chat history"""
        return self.chat_history
    
    def clear_memory(self):
        """Clear chat history and reset booking flow"""
        self.chat_history = []
        self.booking_flow.reset_booking_flow()
    
    def process_message(self, message: str) -> str:
        """Process user message and generate response"""
        try:
            # Add user message to history
            self.add_message("user", message)
            
            # Detect intent
            intent = self._detect_intent(message)
            
            # Route to appropriate handler
            if intent == "booking":
                response = self._handle_booking_intent(message)
            elif intent == "rag_query":
                response = self._handle_rag_query(message)
            elif intent == "admin":
                response = self._handle_admin_intent(message)
            elif intent == "greeting":
                response = self._handle_greeting(message)
            elif intent == "help":
                response = self._handle_help()
            else:
                response = self._handle_general_query(message)
            
            # Add assistant response to history
            self.add_message("assistant", response)
            
            return response
            
        except Exception as e:
            error_msg = f"I apologize, but I encountered an error: {str(e)}"
            self.add_message("assistant", error_msg)
            return error_msg
    
    def _detect_intent(self, message: str) -> str:
        """Detect user intent from message"""
        message_lower = message.lower()
        
        # Booking intent keywords
        booking_keywords = [
            'book', 'booking', 'appointment', 'schedule', 'reserve',
            'make a booking', 'want to book', 'need an appointment'
        ]
        
        # RAG query keywords
        rag_keywords = [
            'what', 'how', 'why', 'when', 'where', 'who', 'tell me about',
            'explain', 'describe', 'information', 'details', 'help me understand'
        ]
        
        # Admin keywords
        admin_keywords = [
            'admin', 'dashboard', 'bookings', 'show bookings', 'view bookings',
            'manage bookings', 'statistics', 'stats'
        ]
        
        # Greeting keywords
        greeting_keywords = [
            'hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening',
            'greetings', 'how are you'
        ]
        
        # Help keywords
        help_keywords = [
            'help', 'what can you do', 'how to use', 'instructions', 'guide'
        ]
        
        # Check for booking intent
        if any(keyword in message_lower for keyword in booking_keywords):
            return "booking"
        
        # Check for admin intent
        elif any(keyword in message_lower for keyword in admin_keywords):
            return "admin"
        
        # Check for greeting
        elif any(keyword in message_lower for keyword in greeting_keywords):
            return "greeting"
        
        # Check for help
        elif any(keyword in message_lower for keyword in help_keywords):
            return "help"
        
        # Check for RAG query (default for questions)
        elif any(keyword in message_lower for keyword in rag_keywords):
            return "rag_query"
        
        # Check if we're in the middle of a booking flow
        elif self.booking_flow.get_missing_slots() or self.booking_flow.needs_confirmation():
            return "booking"
        
        # Default to general query
        else:
            return "general"
    
    def _handle_booking_intent(self, message: str) -> str:
        """Handle booking-related messages"""
        try:
            # If booking is already completed, start a new booking
            if self.booking_flow.is_booking_complete():
                self.booking_flow.reset_booking_flow()
            
            # Extract booking information
            extracted_info = self.booking_flow.extract_booking_info(message)
            self.booking_flow.update_booking_slots(extracted_info)
            
            # Check if confirmation is being processed
            if self.booking_flow.confirmation_requested:
                result = self.booking_flow.process_confirmation(message)
                
                if result.get("success"):
                    # Send confirmation email
                    booking_data = result.get("booking_details", {})
                    booking_id = result.get("booking_id", "")
                    
                    email_result = self.tool_router.call_tool(
                        "email", 
                        "send_booking_confirmation",
                        booking_data=booking_data,
                        booking_id=booking_id
                    )
                    
                    if not email_result.get("success"):
                        # Add email failure notice to the success message
                        result["message"] += f" Note: {email_result['message']}"
                    
                    # Reset booking flow
                    self.booking_flow.reset_booking_flow()
                    return result["message"]
                
                elif "request_change" in result:
                    # User wants to change a specific field
                    return result["message"]
                
                else:
                    return result["message"]
            
            # Check if all slots are filled and confirmation is needed
            elif self.booking_flow.needs_confirmation():
                self.booking_flow.confirmation_requested = True
                return self.booking_flow.generate_confirmation_summary()
            
            # Check if we need to ask for more information
            else:
                missing_slots = self.booking_flow.get_missing_slots()
                if missing_slots:
                    next_question = self.booking_flow.get_next_question()
                    
                    # Add context about what we already have
                    progress = self.booking_flow.get_booking_progress()
                    filled_slots = [k for k, v in progress['slots'].items() if v is not None]
                    
                    if filled_slots:
                        context = "I have the following information: "
                        slot_info = []
                        for slot in filled_slots:
                            if slot in progress['slots']:
                                slot_info.append(f"{slot.replace('_', ' ').title()}: {progress['slots'][slot]}")
                        context += ", ".join(slot_info) + ".\n\n"
                        
                        return context + next_question
                    else:
                        return next_question
                else:
                    return "I have all the information needed. Let me prepare your booking summary."
        
        except Exception as e:
            return f"I apologize, but there was an error processing your booking: {str(e)}"
    
    def _handle_rag_query(self, message: str) -> str:
        """Handle RAG knowledge base queries"""
        try:
            result = self.tool_router.call_tool("rag", "query", question=message)
            
            if result.get("success"):
                response = result.get("answer", "")
                
                # Add sources if available
                sources = result.get("sources", [])
                if sources:
                    response += "\n\n**Sources:**\n"
                    for i, source in enumerate(sources[:3], 1):
                        response += f"{i}. {source}\n"
                
                return response
            else:
                return result.get("answer", "I'm sorry, I couldn't process your query. Please make sure you've uploaded PDF documents first.")
        
        except Exception as e:
            return f"I apologize, but there was an error processing your query: {str(e)}"
    
    def _handle_admin_intent(self, message: str) -> str:
        """Handle admin-related requests"""
        return "For admin functions, please use the Admin Dashboard from the sidebar menu."
    
    def _handle_greeting(self, message: str) -> str:
        """Handle greeting messages"""
        greetings = [
            "Hello! I'm your AI Booking Assistant. How can I help you today?",
            "Hi there! I can help you with bookings and answer questions about our services. What would you like to know?",
            "Welcome! I'm here to assist you with bookings and provide information from our knowledge base. How may I help you?"
        ]
        
        # Simple rotation based on message content
        if "good morning" in message.lower():
            return "Good morning! I'm here to help you with bookings and answer any questions you might have."
        elif "good afternoon" in message.lower():
            return "Good afternoon! How can I assist you with your booking needs today?"
        elif "good evening" in message.lower():
            return "Good evening! I'm here to help you with bookings and provide information."
        else:
            import random
            return random.choice(greetings)
    
    def _handle_help(self) -> str:
        """Handle help requests"""
        help_text = """
# 🤖 AI Booking Assistant - Help

## What I can do:

### 📅 **Booking Services**
- Make appointments and reservations
- Collect your information through conversation
- Send confirmation emails
- Handle various booking types (Doctor, Salon, Hotel, Events, Classes, Restaurant)

### 📄 **Knowledge Base**
- Answer questions based on uploaded PDF documents
- Provide information about services and policies
- Extract relevant information from documents

### 💬 **How to Use:**

**For Bookings:**
1. Say "I want to book" or "I need an appointment"
2. I'll ask for your name, email, phone, booking type, date, and time
3. I'll confirm all details with you before finalizing
4. You'll receive a confirmation email

**For Questions:**
1. Upload PDF documents using the upload section
2. Ask questions about the content
3. I'll provide answers based on the uploaded documents

**Example Commands:**
- "I want to book a doctor appointment"
- "What are your opening hours?"
- "Tell me about your services"
- "Show me my bookings" (use Admin Dashboard)

---

Feel free to ask me anything or start a booking! 🚀
        """
        
        return help_text
    
    def _handle_general_query(self, message: str) -> str:
        """Handle general queries that don't fit other categories"""
        # Try RAG first in case it's a question about uploaded documents
        rag_result = self.tool_router.call_tool("rag", "query", question=message)
        
        if rag_result.get("success") and rag_result.get("answer"):
            return rag_result["answer"]
        
        # If no RAG results, provide a general response
        general_responses = [
            "I'm here to help you with bookings and answer questions based on uploaded documents. You can ask me to make a booking or upload PDFs to ask questions about their content.",
            "I can assist you with making bookings or answering questions from uploaded PDF documents. What would you like to do today?",
            "Would you like to make a booking, or do you have questions about our services? You can also upload PDF documents for me to reference."
        ]
        
        import random
        return random.choice(general_responses)
    
    def process_pdf(self, pdf_file) -> bool:
        """Process uploaded PDF file"""
        try:
            result = self.tool_router.call_tool("rag", "process_pdf", pdf_file=pdf_file)
            return result.get("success", False)
        except Exception as e:
            st.error(f"Error processing PDF: {str(e)}")
            return False
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def get_rag_status(self) -> Dict[str, Any]:
        """Get RAG system status"""
        return self.tool_router.call_tool("rag", "get_status")
