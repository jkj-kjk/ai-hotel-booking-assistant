import streamlit as st

def render_booking_success():
    """Render booking success page"""
    st.title("🎉 Booking Successful!")
    
    # Success message
    st.success("✅ Your hotel booking has been confirmed!")
    
    # Booking details display
    if 'booking_data' in st.session_state and 'selected_hotel' in st.session_state:
        with st.container():
            st.markdown("### 📋 Booking Summary")
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"**Hotel:** {st.session_state.selected_hotel['name']}")
                st.markdown(f"**Booking ID:** {st.session_state.get('booking_id', 'Processing...')}")
                st.markdown(f"**Guest Name:** {st.session_state.booking_data.get('name', 'N/A')}")
                st.markdown(f"**Email:** {st.session_state.booking_data.get('email', 'N/A')}")
            
            with col2:
                st.markdown(f"**Check-in:** {st.session_state.booking_data.get('check_in', 'N/A')}")
                st.markdown(f"**Check-out:** {st.session_state.booking_data.get('check_out', 'N/A')}")
                st.markdown(f"**Guests:** {st.session_state.booking_data.get('adults', 0)} adults, {st.session_state.booking_data.get('children', 0)} children")
                st.markdown(f"**Rooms:** {st.session_state.booking_data.get('rooms', 0)}")
    
    # Action buttons
    st.markdown("---")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🏨 Back to Hotels", key="back_to_hotels", use_container_width=True):
            st.session_state.current_page = "hotel_booking"
            st.rerun()
    
    with col2:
        if st.button("📊 View All Bookings", key="view_bookings", use_container_width=True):
            st.session_state.current_page = "admin"
            st.rerun()
    
    with col3:
        if st.button("🏨 Book Another Hotel", key="book_another", use_container_width=True):
            st.session_state.current_page = "hotel_booking"
            st.rerun()
    
    # Additional information
    with st.expander("ℹ️ What's Next?"):
        st.markdown("""
        ### 📧 Email Confirmation
        You will receive a confirmation email shortly with your booking details.
        
        ### 📞 Contact Hotel
        If you need to modify or cancel your booking, please contact the hotel directly.
        
        ### 🏨 Explore More Options
        - Browse more hotels in different locations
        - Check out special offers and discounts
        - Read reviews from other guests
        """)
    
    # AI Assistant for follow-up questions
    st.markdown("---")
    st.subheader("💬 Have Questions?")
    
    question = st.text_input("Ask me anything about your booking or our services:", 
                         placeholder="Type your question here...",
                         key="followup_question")
    
    if st.button("🤔 Ask", key="ask_followup"):
        if question:
            # Here you could integrate with the chat logic
            st.info("🤖 AI Assistant is processing your question...")
            # In a real implementation, this would call the chat logic
