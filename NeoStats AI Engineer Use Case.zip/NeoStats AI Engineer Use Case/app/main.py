import streamlit as st
import sys
import os

# Add the root directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.chat_logic import ChatLogic
from app.admin_dashboard import AdminDashboard
from app.config import Config

def main():
    st.set_page_config(
        page_title="AI Booking Assistant",
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    if 'chat_logic' not in st.session_state:
        st.session_state.chat_logic = ChatLogic()
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "chat"
    
    # Sidebar navigation
    with st.sidebar:
        st.title("🤖 AI Booking Assistant")
        st.markdown("---")
        
        if st.button("💬 Chat Interface", key="chat_btn", use_container_width=True):
            st.session_state.current_page = "chat"
        
        if st.button("📊 Admin Dashboard", key="admin_btn", use_container_width=True):
            st.session_state.current_page = "admin"
        
        st.markdown("---")
        st.markdown("### Features:")
        st.markdown("- 📄 PDF Upload & RAG")
        st.markdown("- 🗣️ Conversational Booking")
        st.markdown("- 📧 Email Confirmations")
        st.markdown("- 💾 Data Storage")
        
        # Clear conversation button
        if st.button("🗑️ Clear Conversation", key="clear_btn", use_container_width=True):
            st.session_state.chat_logic.clear_memory()
            st.success("Conversation cleared!")
            st.rerun()
    
    # Route to appropriate page
    if st.session_state.current_page == "chat":
        render_chat_interface()
    elif st.session_state.current_page == "admin":
        render_admin_interface()

def render_chat_interface():
    st.title("💬 AI Booking Assistant")
    st.markdown("Upload PDFs for knowledge base and chat with our AI assistant for bookings!")
    
    # PDF upload section
    with st.expander("📄 Upload PDF Documents", expanded=False):
        uploaded_files = st.file_uploader(
            "Choose PDF files",
            type="pdf",
            accept_multiple_files=True,
            key="pdf_uploader"
        )
        
        if uploaded_files:
            if st.button("📥 Process PDFs", key="process_pdfs"):
                with st.spinner("Processing PDFs..."):
                    try:
                        for file in uploaded_files:
                            st.session_state.chat_logic.process_pdf(file)
                        st.success(f"Successfully processed {len(uploaded_files)} PDF(s)!")
                    except Exception as e:
                        st.error(f"Error processing PDFs: {str(e)}")
    
    # Chat interface
    st.markdown("---")
    st.subheader("Chat with AI Assistant")
    
    # Display chat messages
    for message in st.session_state.chat_logic.get_chat_history():
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Chat input
    if prompt := st.chat_input("Type your message here..."):
        with st.chat_message("user"):
            st.markdown(prompt)
        
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    response = st.session_state.chat_logic.process_message(prompt)
                    st.markdown(response)
                except Exception as e:
                    st.error(f"Error: {str(e)}")

def render_admin_interface():
    dashboard = AdminDashboard()
    dashboard.render()

if __name__ == "__main__":
    main()
