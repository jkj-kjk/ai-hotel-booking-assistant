import os
import streamlit as st
from typing import Dict, Any

class Config:
    """Configuration settings for the AI Booking Assistant"""
    
    # Database settings
    DATABASE_TYPE = "sqlite"  # or "supabase"
    SQLITE_DB_PATH = "bookings.db"
    
    # Supabase settings (if used)
    SUPABASE_URL = st.secrets.get("SUPABASE_URL", "")
    SUPABASE_KEY = st.secrets.get("SUPABASE_KEY", "")
    
    # Email settings
    EMAIL_PROVIDER = st.secrets.get("EMAIL_PROVIDER", "smtp")
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587
    SMTP_USERNAME = st.secrets.get("SMTP_USERNAME", "")
    SMTP_PASSWORD = st.secrets.get("SMTP_PASSWORD", "")
    EMAIL_FROM = st.secrets.get("EMAIL_FROM", "noreply@bookingassistant.com")
    
    # SendGrid settings (if used)
    SENDGRID_API_KEY = st.secrets.get("SENDGRID_API_KEY", "")
    
    # LLM settings
    OPENAI_API_KEY = st.secrets.get("OPENAI_API_KEY", "")
    OPENAI_MODEL = "gpt-3.5-turbo"
    
    # Embedding settings
    EMBEDDING_MODEL = "text-embedding-ada-002"
    VECTOR_STORE_TYPE = "chroma"  # or "faiss"
    CHROMA_PERSIST_DIR = "chroma_db"
    
    # Chat settings
    MAX_MEMORY_LENGTH = 25
    BOOKING_CONFIRMATION_REQUIRED = True
    
    # PDF processing settings
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    
    # Booking types (customize based on your domain)
    BOOKING_TYPES = [
        "Doctor Consultation",
        "Salon Appointment", 
        "Hotel Reservation",
        "Event Registration",
        "Class Booking",
        "Restaurant Reservation"
    ]
    
    @classmethod
    def get_email_config(cls) -> Dict[str, Any]:
        """Get email configuration based on provider"""
        if cls.EMAIL_PROVIDER == "smtp":
            return {
                "provider": "smtp",
                "server": cls.SMTP_SERVER,
                "port": cls.SMTP_PORT,
                "username": cls.SMTP_USERNAME,
                "password": cls.SMTP_PASSWORD,
                "from_email": cls.EMAIL_FROM
            }
        elif cls.EMAIL_PROVIDER == "sendgrid":
            return {
                "provider": "sendgrid",
                "api_key": cls.SENDGRID_API_KEY,
                "from_email": cls.EMAIL_FROM
            }
        else:
            raise ValueError(f"Unsupported email provider: {cls.EMAIL_PROVIDER}")
    
    @classmethod
    def get_database_config(cls) -> Dict[str, Any]:
        """Get database configuration"""
        if cls.DATABASE_TYPE == "sqlite":
            return {
                "type": "sqlite",
                "path": cls.SQLITE_DB_PATH
            }
        elif cls.DATABASE_TYPE == "supabase":
            return {
                "type": "supabase",
                "url": cls.SUPABASE_URL,
                "key": cls.SUPABASE_KEY
            }
        else:
            raise ValueError(f"Unsupported database type: {cls.DATABASE_TYPE}")
    
    @classmethod
    def validate_config(cls) -> bool:
        """Validate essential configuration settings"""
        errors = []
        
        if cls.DATABASE_TYPE == "supabase":
            if not cls.SUPABASE_URL:
                errors.append("SUPABASE_URL is required for Supabase")
            if not cls.SUPABASE_KEY:
                errors.append("SUPABASE_KEY is required for Supabase")
        
        if cls.EMAIL_PROVIDER == "smtp":
            if not cls.SMTP_USERNAME:
                errors.append("SMTP_USERNAME is required for SMTP")
            if not cls.SMTP_PASSWORD:
                errors.append("SMTP_PASSWORD is required for SMTP")
        elif cls.EMAIL_PROVIDER == "sendgrid":
            if not cls.SENDGRID_API_KEY:
                errors.append("SENDGRID_API_KEY is required for SendGrid")
        
        if not cls.OPENAI_API_KEY:
            errors.append("OPENAI_API_KEY is required")
        
        if errors:
            print("Configuration errors:")
            for error in errors:
                print(f"  - {error}")
            return False
        
        return True
