import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any, Optional
import requests
import streamlit as st

from app.config import Config
from app.rag_pipeline import RAGPipeline
from db.database import DatabaseService

class RAGTool:
    """Tool for RAG (Retrieval-Augmented Generation) queries"""
    
    def __init__(self):
        self.rag_pipeline = RAGPipeline()
    
    def query(self, question: str) -> Dict[str, Any]:
        """Query the RAG system"""
        try:
            if not self.rag_pipeline.is_ready():
                return {
                    "success": False,
                    "answer": "Please upload PDF documents first to enable knowledge base queries.",
                    "sources": []
                }
            
            result = self.rag_pipeline.query(question)
            
            return {
                "success": result.get("success", False),
                "answer": result.get("answer", ""),
                "sources": [doc.page_content[:200] + "..." for doc in result.get("source_documents", [])]
            }
            
        except Exception as e:
            return {
                "success": False,
                "answer": f"Error processing query: {str(e)}",
                "sources": []
            }
    
    def process_pdf(self, pdf_file) -> Dict[str, Any]:
        """Process a PDF file"""
        try:
            success = self.rag_pipeline.process_pdf(pdf_file)
            
            return {
                "success": success,
                "message": "PDF processed successfully" if success else "Failed to process PDF",
                "processed_files": self.rag_pipeline.get_processed_files(),
                "document_count": self.rag_pipeline.get_document_count()
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error processing PDF: {str(e)}",
                "processed_files": self.rag_pipeline.get_processed_files(),
                "document_count": 0
            }
    
    def get_status(self) -> Dict[str, Any]:
        """Get RAG system status"""
        return {
            "ready": self.rag_pipeline.is_ready(),
            "processed_files": self.rag_pipeline.get_processed_files(),
            "document_count": self.rag_pipeline.get_document_count()
        }

class BookingPersistenceTool:
    """Tool for booking persistence operations"""
    
    def __init__(self):
        self.db_service = DatabaseService()
    
    def create_booking(self, booking_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new booking"""
        try:
            # Validate booking data
            is_valid, errors = self.db_service.validate_booking_data(booking_data)
            if not is_valid:
                return {
                    "success": False,
                    "message": f"Validation errors: {'; '.join(errors)}",
                    "booking_id": None
                }
            
            # Create or get customer
            customer_id = self.db_service.create_or_get_customer(
                booking_data['name'],
                booking_data['email'],
                booking_data['phone']
            )
            
            # Create booking
            booking_id = self.db_service.create_booking(
                customer_id=customer_id,
                booking_type=booking_data['booking_type'],
                date=booking_data['date'],
                time=booking_data['time'],
                additional_info=booking_data.get('additional_info')
            )
            
            return {
                "success": True,
                "message": "Booking created successfully",
                "booking_id": booking_id
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error creating booking: {str(e)}",
                "booking_id": None
            }
    
    def get_bookings(self, search_query: Optional[str] = None) -> Dict[str, Any]:
        """Get bookings, optionally filtered by search query"""
        try:
            if search_query:
                bookings = self.db_service.search_bookings(search_query)
            else:
                bookings = self.db_service.get_all_bookings()
            
            return {
                "success": True,
                "bookings": bookings,
                "count": len(bookings)
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error retrieving bookings: {str(e)}",
                "bookings": [],
                "count": 0
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get booking statistics"""
        try:
            stats = self.db_service.get_booking_stats()
            return {
                "success": True,
                "stats": stats
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error retrieving stats: {str(e)}",
                "stats": {}
            }

class EmailTool:
    """Tool for sending email notifications"""
    
    def __init__(self):
        self.email_config = Config.get_email_config()
    
    def send_booking_confirmation(self, booking_data: Dict[str, Any], booking_id: str) -> Dict[str, Any]:
        """Send booking confirmation email"""
        try:
            subject = f"Booking Confirmation - {booking_id[:8].upper()}"
            
            body = self._generate_confirmation_email_body(booking_data, booking_id)
            
            result = self.send_email(
                to_email=booking_data['email'],
                subject=subject,
                body=body
            )
            
            return result
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error sending booking confirmation: {str(e)}"
            }
    
    def send_email(self, to_email: str, subject: str, body: str) -> Dict[str, Any]:
        """Send an email"""
        try:
            if self.email_config["provider"] == "smtp":
                return self._send_smtp_email(to_email, subject, body)
            elif self.email_config["provider"] == "sendgrid":
                return self._send_sendgrid_email(to_email, subject, body)
            else:
                return {
                    "success": False,
                    "message": f"Unsupported email provider: {self.email_config['provider']}"
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"Error sending email: {str(e)}"
            }
    
    def _send_smtp_email(self, to_email: str, subject: str, body: str) -> Dict[str, Any]:
        """Send email using SMTP"""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_config['from_email']
            msg['To'] = to_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'html'))
            
            server = smtplib.SMTP(self.email_config['server'], self.email_config['port'])
            server.starttls()
            server.login(self.email_config['username'], self.email_config['password'])
            
            text = msg.as_string()
            server.sendmail(self.email_config['from_email'], to_email, text)
            server.quit()
            
            return {
                "success": True,
                "message": "Email sent successfully via SMTP"
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"SMTP error: {str(e)}"
            }
    
    def _send_sendgrid_email(self, to_email: str, subject: str, body: str) -> Dict[str, Any]:
        """Send email using SendGrid"""
        try:
            url = "https://api.sendgrid.com/v3/mail/send"
            
            data = {
                "personalizations": [{
                    "to": [{"email": to_email}],
                    "subject": subject
                }],
                "from": {"email": self.email_config['from_email']},
                "content": [{
                    "type": "text/html",
                    "value": body
                }]
            }
            
            headers = {
                "Authorization": f"Bearer {self.email_config['api_key']}",
                "Content-Type": "application/json"
            }
            
            response = requests.post(url, json=data, headers=headers)
            
            if response.status_code == 202:
                return {
                    "success": True,
                    "message": "Email sent successfully via SendGrid"
                }
            else:
                return {
                    "success": False,
                    "message": f"SendGrid error: {response.status_code} - {response.text}"
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"SendGrid error: {str(e)}"
            }
    
    def _generate_confirmation_email_body(self, booking_data: Dict[str, Any], booking_id: str) -> str:
        """Generate HTML body for booking confirmation email"""
        body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 10px;">
                <h2 style="color: #333; text-align: center;">🎉 Booking Confirmed!</h2>
                
                <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #007bff;">Booking Details</h3>
                    <p><strong>Booking ID:</strong> {booking_id[:8].upper()}</p>
                    <p><strong>Name:</strong> {booking_data['name']}</p>
                    <p><strong>Email:</strong> {booking_data['email']}</p>
                    <p><strong>Phone:</strong> {booking_data['phone']}</p>
                    <p><strong>Booking Type:</strong> {booking_data['booking_type']}</p>
                    <p><strong>Date:</strong> {booking_data['date']}</p>
                    <p><strong>Time:</strong> {booking_data['time']}</p>
                </div>
                
                <div style="text-align: center; margin: 20px 0;">
                    <p style="color: #666;">Please arrive 10 minutes before your scheduled time.</p>
                    <p style="color: #666;">If you need to make any changes, please contact us.</p>
                </div>
                
                <div style="text-align: center; color: #999; font-size: 12px;">
                    <p>This is an automated confirmation email.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return body

class WebSearchTool:
    """Optional tool for web search functionality"""
    
    def __init__(self):
        # Using a free API or placeholder implementation
        pass
    
    def search(self, query: str) -> Dict[str, Any]:
        """Perform web search (placeholder implementation)"""
        try:
            # This is a placeholder - in a real implementation, you would use
            # a search API like Google Search API, Bing Search API, etc.
            
            return {
                "success": False,
                "message": "Web search functionality not implemented in this demo",
                "results": []
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Web search error: {str(e)}",
                "results": []
            }

class ToolRouter:
    """Router for managing and calling different tools"""
    
    def __init__(self):
        self.rag_tool = RAGTool()
        self.booking_tool = BookingPersistenceTool()
        self.email_tool = EmailTool()
        self.web_search_tool = WebSearchTool()
    
    def call_tool(self, tool_name: str, method: str, **kwargs) -> Dict[str, Any]:
        """Call a specific tool method"""
        try:
            if tool_name == "rag":
                if method == "query":
                    return self.rag_tool.query(kwargs.get("question", ""))
                elif method == "process_pdf":
                    return self.rag_tool.process_pdf(kwargs.get("pdf_file"))
                elif method == "get_status":
                    return self.rag_tool.get_status()
            
            elif tool_name == "booking":
                if method == "create_booking":
                    return self.booking_tool.create_booking(kwargs.get("booking_data", {}))
                elif method == "get_bookings":
                    return self.booking_tool.get_bookings(kwargs.get("search_query"))
                elif method == "get_stats":
                    return self.booking_tool.get_stats()
            
            elif tool_name == "email":
                if method == "send_booking_confirmation":
                    return self.email_tool.send_booking_confirmation(
                        kwargs.get("booking_data", {}),
                        kwargs.get("booking_id", "")
                    )
                elif method == "send_email":
                    return self.email_tool.send_email(
                        kwargs.get("to_email", ""),
                        kwargs.get("subject", ""),
                        kwargs.get("body", "")
                    )
            
            elif tool_name == "web_search":
                if method == "search":
                    return self.web_search_tool.search(kwargs.get("query", ""))
            
            return {
                "success": False,
                "message": f"Unknown tool or method: {tool_name}.{method}"
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Tool execution error: {str(e)}"
            }
