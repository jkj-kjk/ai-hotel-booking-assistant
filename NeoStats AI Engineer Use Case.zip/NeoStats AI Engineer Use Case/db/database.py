from typing import Optional, Dict, Any, List
import sqlite3
from datetime import datetime
import os

from db.models import Customer, Booking, DatabaseManager
from app.config import Config

class DatabaseService:
    """Service layer for database operations"""
    
    def __init__(self):
        config = Config.get_database_config()
        if config["type"] == "sqlite":
            self.db_manager = DatabaseManager(config["path"])
        else:
            raise NotImplementedError("Supabase not implemented yet")
    
    def create_or_get_customer(self, name: str, email: str, phone: str) -> str:
        """Create a new customer or get existing one by email"""
        # Check if customer exists
        existing_customer = self.db_manager.get_customer_by_email(email)
        if existing_customer:
            return existing_customer.customer_id
        
        # Create new customer
        customer = Customer(name=name, email=email, phone=phone)
        return self.db_manager.create_customer(customer)
    
    def create_booking(self, customer_id: str, booking_type: str, 
                      date: str, time: str, additional_info: Optional[Dict[str, Any]] = None) -> str:
        """Create a new booking"""
        booking = Booking(
            customer_id=customer_id,
            booking_type=booking_type,
            date=date,
            time=time,
            additional_info=additional_info
        )
        return self.db_manager.create_booking(booking)
    
    def get_all_bookings(self) -> List[Dict[str, Any]]:
        """Get all bookings with customer information"""
        return self.db_manager.get_all_bookings()
    
    def search_bookings(self, query: str) -> List[Dict[str, Any]]:
        """Search bookings by customer name, email, or booking type"""
        return self.db_manager.search_bookings(query)
    
    def get_booking_stats(self) -> Dict[str, Any]:
        """Get booking statistics"""
        return self.db_manager.get_booking_stats()
    
    def validate_booking_data(self, booking_data: Dict[str, Any]) -> tuple[bool, List[str]]:
        """Validate booking data and return (is_valid, error_messages)"""
        errors = []
        
        # Required fields
        required_fields = ['name', 'email', 'phone', 'booking_type', 'date', 'time']
        for field in required_fields:
            if field not in booking_data or not booking_data[field]:
                errors.append(f"{field.replace('_', ' ').title()} is required")
        
        # Email validation
        if 'email' in booking_data:
            email = booking_data['email']
            if '@' not in email or '.' not in email:
                errors.append("Please enter a valid email address")
        
        # Phone validation (basic)
        if 'phone' in booking_data:
            phone = booking_data['phone']
            if len(phone.replace('-', '').replace(' ', '').replace('+', '')) < 10:
                errors.append("Please enter a valid phone number")
        
        # Date validation (YYYY-MM-DD format)
        if 'date' in booking_data:
            date = booking_data['date']
            try:
                datetime.strptime(date, '%Y-%m-%d')
            except ValueError:
                errors.append("Date must be in YYYY-MM-DD format")
        
        # Time validation (HH:MM format)
        if 'time' in booking_data:
            time = booking_data['time']
            try:
                datetime.strptime(time, '%H:%M')
            except ValueError:
                errors.append("Time must be in HH:MM format")
        
        # Booking type validation
        if 'booking_type' in booking_data:
            booking_type = booking_data['booking_type']
            if booking_type not in Config.BOOKING_TYPES:
                errors.append(f"Booking type must be one of: {', '.join(Config.BOOKING_TYPES)}")
        
        return len(errors) == 0, errors
