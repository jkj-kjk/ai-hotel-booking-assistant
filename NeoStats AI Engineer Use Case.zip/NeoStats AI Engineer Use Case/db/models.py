from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, EmailStr
import sqlite3
import uuid

class Customer(BaseModel):
    """Customer model for database operations"""
    customer_id: Optional[str] = None
    name: str
    email: EmailStr
    phone: str
    created_at: Optional[datetime] = None
    
    def __init__(self, **data):
        if not data.get('customer_id'):
            data['customer_id'] = str(uuid.uuid4())
        if not data.get('created_at'):
            data['created_at'] = datetime.now()
        super().__init__(**data)

class Booking(BaseModel):
    """Booking model for database operations"""
    id: Optional[str] = None
    customer_id: str
    booking_type: str
    date: str  # Format: YYYY-MM-DD
    time: str  # Format: HH:MM
    status: str = "confirmed"
    created_at: Optional[datetime] = None
    additional_info: Optional[Dict[str, Any]] = None
    
    def __init__(self, **data):
        if not data.get('id'):
            data['id'] = str(uuid.uuid4())
        if not data.get('created_at'):
            data['created_at'] = datetime.now()
        super().__init__(**data)

class DatabaseManager:
    """Database manager for SQLite operations"""
    
    def __init__(self, db_path: str = "bookings.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create customers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS customers (
                    customer_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    phone TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create bookings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bookings (
                    id TEXT PRIMARY KEY,
                    customer_id TEXT NOT NULL,
                    booking_type TEXT NOT NULL,
                    date TEXT NOT NULL,
                    time TEXT NOT NULL,
                    status TEXT DEFAULT 'confirmed',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    additional_info TEXT,
                    FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                )
            ''')
            
            conn.commit()
    
    def create_customer(self, customer: Customer) -> str:
        """Create a new customer"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    INSERT INTO customers (customer_id, name, email, phone, created_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (customer.customer_id, customer.name, customer.email, 
                      customer.phone, customer.created_at))
                conn.commit()
                return customer.customer_id
            except sqlite3.IntegrityError as e:
                if "UNIQUE constraint failed" in str(e):
                    # Customer with this email already exists, get existing customer_id
                    cursor.execute('SELECT customer_id FROM customers WHERE email = ?', 
                                 (customer.email,))
                    result = cursor.fetchone()
                    if result:
                        return result[0]
                raise e
    
    def create_booking(self, booking: Booking) -> str:
        """Create a new booking"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO bookings (id, customer_id, booking_type, date, time, 
                                    status, created_at, additional_info)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (booking.id, booking.customer_id, booking.booking_type,
                  booking.date, booking.time, booking.status, booking.created_at,
                  str(booking.additional_info) if booking.additional_info else None))
            conn.commit()
            return booking.id
    
    def get_customer_by_email(self, email: str) -> Optional[Customer]:
        """Get customer by email"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM customers WHERE email = ?', (email,))
            row = cursor.fetchone()
            if row:
                return Customer(
                    customer_id=row[0],
                    name=row[1],
                    email=row[2],
                    phone=row[3],
                    created_at=datetime.fromisoformat(row[4]) if row[4] else None
                )
        return None
    
    def get_all_bookings(self) -> list:
        """Get all bookings with customer information"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT b.id, b.customer_id, b.booking_type, b.date, b.time, 
                       b.status, b.created_at, b.additional_info,
                       c.name, c.email, c.phone
                FROM bookings b
                JOIN customers c ON b.customer_id = c.customer_id
                ORDER BY b.created_at DESC
            ''')
            
            bookings = []
            for row in cursor.fetchall():
                bookings.append({
                    'id': row[0],
                    'customer_id': row[1],
                    'booking_type': row[2],
                    'date': row[3],
                    'time': row[4],
                    'status': row[5],
                    'created_at': row[6],
                    'additional_info': row[7],
                    'customer_name': row[8],
                    'customer_email': row[9],
                    'customer_phone': row[10]
                })
            
            return bookings
    
    def search_bookings(self, query: str) -> list:
        """Search bookings by name, email, or booking type"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT b.id, b.customer_id, b.booking_type, b.date, b.time, 
                       b.status, b.created_at, b.additional_info,
                       c.name, c.email, c.phone
                FROM bookings b
                JOIN customers c ON b.customer_id = c.customer_id
                WHERE c.name LIKE ? OR c.email LIKE ? OR b.booking_type LIKE ?
                ORDER BY b.created_at DESC
            ''', (f'%{query}%', f'%{query}%', f'%{query}%'))
            
            bookings = []
            for row in cursor.fetchall():
                bookings.append({
                    'id': row[0],
                    'customer_id': row[1],
                    'booking_type': row[2],
                    'date': row[3],
                    'time': row[4],
                    'status': row[5],
                    'created_at': row[6],
                    'additional_info': row[7],
                    'customer_name': row[8],
                    'customer_email': row[9],
                    'customer_phone': row[10]
                })
            
            return bookings
    
    def get_booking_stats(self) -> Dict[str, Any]:
        """Get booking statistics"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Total bookings
            cursor.execute('SELECT COUNT(*) FROM bookings')
            total_bookings = cursor.fetchone()[0]
            
            # Bookings by type
            cursor.execute('''
                SELECT booking_type, COUNT(*) 
                FROM bookings 
                GROUP BY booking_type
            ''')
            bookings_by_type = dict(cursor.fetchall())
            
            # Recent bookings (last 7 days)
            cursor.execute('''
                SELECT COUNT(*) FROM bookings 
                WHERE created_at >= date('now', '-7 days')
            ''')
            recent_bookings = cursor.fetchone()[0]
            
            return {
                'total_bookings': total_bookings,
                'bookings_by_type': bookings_by_type,
                'recent_bookings': recent_bookings
            }
