"""
Database Package for AI Booking Assistant

This package contains database models and services:
- SQLite database models (Customer, Booking)
- Database manager for operations
- Service layer for business logic
"""

__version__ = "1.0.0"
