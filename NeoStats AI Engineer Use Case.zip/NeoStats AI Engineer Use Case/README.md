# 🤖 AI Booking Assistant

A comprehensive AI-driven booking assistant that combines RAG (Retrieval-Augmented Generation) capabilities with conversational booking flows, email confirmations, and an admin dashboard.

## ✨ Features

### 🎯 Core Functionality
- **💬 Chat-based Interface**: Natural language conversation with AI assistant
- **📄 RAG System**: Upload and query PDF documents for knowledge base
- **🗣️ Conversational Booking**: Multi-turn dialogue for collecting booking details
- **📧 Email Confirmations**: Automated booking confirmation emails
- **📊 Admin Dashboard**: View, search, and analyze all bookings
- **💾 Data Persistence**: SQLite database storage (easily switchable to Supabase)

### 🛠️ Technical Features
- **Intent Detection**: Automatically identifies booking vs. general queries
- **Slot Filling**: Intelligently collects required booking information
- **Short-term Memory**: Maintains conversation context (last 20-25 messages)
- **Error Handling**: Comprehensive validation and graceful error management
- **Tool Calling**: Modular architecture with dedicated tools for different functions

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- OpenAI API key
- Email service credentials (Gmail SMTP or SendGrid)

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd ai-booking-assistant
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables**
Create a `.streamlit/secrets.toml` file and add your API keys:

```toml
OPENAI_API_KEY = "your-openai-api-key"
EMAIL_PROVIDER = "smtp"
SMTP_USERNAME = "your-gmail@gmail.com"
SMTP_PASSWORD = "your-app-password"
EMAIL_FROM = "noreply@yourdomain.com"
```

4. **Run the application**
```bash
streamlit run app/main.py
```

## 📁 Project Structure

```
project_root/
├── app/
│   ├── main.py              # Streamlit entry point
│   ├── chat_logic.py        # Intent detection and conversation management
│   ├── booking_flow.py      # Slot filling and booking confirmation
│   ├── rag_pipeline.py      # PDF processing and RAG implementation
│   ├── tools.py             # RAG, booking, and email tools
│   ├── admin_dashboard.py   # Admin interface for viewing bookings
│   └── config.py            # Configuration settings
├── db/
│   ├── database.py          # Database service layer
│   └── models.py            # Data models (Customer, Booking)
├── docs/                    # Sample PDFs and documentation
├── .streamlit/
│   └── secrets.toml         # API keys and secrets
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## 🎮 Usage Guide

### 📄 Using the RAG System
1. Click "Upload PDF Documents" in the sidebar
2. Select one or more PDF files
3. Click "Process PDFs" to add them to the knowledge base
4. Ask questions about the uploaded content

### 🗣️ Making a Booking
1. Type booking-related phrases like:
   - "I want to book an appointment"
   - "I need to schedule something"
   - "Book a doctor consultation"
2. The assistant will ask for:
   - Name
   - Email
   - Phone
   - Booking type
   - Date and time
3. Confirm the details when prompted
4. Receive a booking confirmation email

### 📊 Admin Dashboard
1. Click "Admin Dashboard" in the sidebar
2. View all bookings with customer information
3. Search and filter bookings
4. Export booking data to CSV
5. View analytics and booking trends

## 🔧 Configuration

### Booking Types
Edit `Config.BOOKING_TYPES` in `app/config.py` to customize available booking types:

```python
BOOKING_TYPES = [
    "Doctor Consultation",
    "Salon Appointment", 
    "Hotel Reservation",
    "Event Registration",
    "Class Booking",
    "Restaurant Reservation"
]
```

### Email Setup
**Gmail SMTP Setup:**
1. Enable 2-factor authentication
2. Generate an App Password
3. Add credentials to `secrets.toml`

**SendGrid Setup:**
1. Create a SendGrid account
2. Generate an API key
3. Update `secrets.toml` with SendGrid configuration

### Database Options
**SQLite (Default):**
- No additional setup required
- Database file: `bookings.db`

**Supabase (Optional):**
1. Create a Supabase project
2. Set up customers and bookings tables
3. Update `secrets.toml` with Supabase credentials

## 🏗️ Architecture

### 🧠 AI Components
- **Intent Detection**: Identifies user intents (booking, RAG query, admin, help)
- **RAG Pipeline**: PDF processing → Text chunking → Embeddings → Vector storage
- **Booking Flow**: Multi-turn conversation with slot filling and confirmation
- **Memory Management**: Maintains conversation context and history

### 🛠️ Tool System
- **RAG Tool**: Knowledge base queries and PDF processing
- **Booking Tool**: Database operations and validation
- **Email Tool**: SMTP/SendGrid email sending
- **Web Search Tool**: (Placeholder for future implementation)

### 📊 Data Flow
1. User input → Intent detection
2. Route to appropriate handler
3. Execute tool calls as needed
4. Generate response and maintain memory
5. Store booking data and send confirmations

## 🚀 Deployment

### Streamlit Cloud (Recommended)
1. Push code to GitHub repository
2. Connect to Streamlit Cloud
3. Add secrets in Streamlit Cloud dashboard
4. Deploy and get public URL

### Local Development
```bash
streamlit run app/main.py --server.port 8501
```

## 🧪 Testing

### Test Features
- PDF upload and RAG responses
- Complete booking flow
- Email confirmations
- Admin dashboard functionality
- Error handling and validation

### Sample Test Cases
1. **RAG Testing**: Upload a PDF and ask questions about its content
2. **Booking Flow**: Complete a full booking with confirmation
3. **Admin Functions**: View bookings, search, and export data
4. **Error Scenarios**: Test invalid inputs and edge cases

## 🔍 Troubleshooting

### Common Issues

**PDF Processing Errors**
- Ensure PDF files contain text (not just images)
- Check file size and format compatibility

**Email Failures**
- Verify SMTP credentials and app passwords
- Check email provider settings and limits

**Database Issues**
- Ensure write permissions for SQLite database
- Check database file location and access rights

**OpenAI API Errors**
- Verify API key is valid and has sufficient credits
- Check rate limits and usage

### Debug Mode
Enable debug logging by setting environment variable:
```bash
export STREAMLIT_LOGGER_LEVEL=debug
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- OpenAI for GPT models and embeddings
- LangChain for RAG framework
- Streamlit for the web interface
- ChromaDB for vector storage

## 📞 Support

For support and questions:
- Create an issue in the GitHub repository
- Check the troubleshooting section above
- Review the code comments and documentation

---

**Built with ❤️ using Streamlit, OpenAI, and LangChain**
